﻿using api.nox.network.RelayInstances.Base;
using api.nox.network.Utils;

namespace api.nox.network.RelayInstances.Quit
{
    public class EventQuit : InstanceResponse
    {
        public QuitType Type;
        public string Reason;
        public byte SharedType;

        public override bool FromBuffer(Buffer buffer)
        {
            Type = buffer.Read<QuitType>();
            if (buffer.Remaining < 1)
                Reason = buffer.ReadString();
            return true;
        }

        public override string ToString() => $"{GetType().Name}[Type={Type}, Reason={Reason}]";

        public void BeforeExport()
        {
            SharedType = (byte)Type;
        }

        public void AfterExport()
        {
            SharedType = 0;
        }
    }
}