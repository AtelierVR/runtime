﻿namespace api.nox.network.RelayInstances.Players
{
    public class PlayerInstance
    {
        
    }
}