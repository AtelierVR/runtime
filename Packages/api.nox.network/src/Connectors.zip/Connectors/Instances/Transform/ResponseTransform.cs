using api.nox.network.RelayInstances.Base;
using api.nox.network.Players;
using api.nox.network.Utils;
namespace api.nox.network.RelayInstances.Transform
{
    public class ResponseTransform : InstanceResponse
    {
        public TransformType Type;
        public Utils.Transform Transform;
        public TransformFlags Flags;

        public string Path;
        public ushort PlayerId;
        public PlayerRig PlayerRig;
        public ushort ObjectId;

        public override bool FromBuffer(Buffer buffer)
        {
            Type = buffer.Read<TransformType>();

            switch (Type)
            {
                case TransformType.ByPath:
                    Path = buffer.Read<string>();
                    break;
                case TransformType.OnPlayer:
                    PlayerId = buffer.Read<ushort>();
                    PlayerRig = buffer.Read<PlayerRig>();
                    break;
                case TransformType.OnObject:
                    ObjectId = buffer.Read<ushort>();
                    break;
                default:
                    return false;
            }

            Flags = buffer.Read<TransformFlags>();
            Transform = new Utils.Transform() { deliveryType = TransformDeliveryType.RemoteModified };
            
            if (Flags.HasFlag(TransformFlags.Position))
                Transform.position = buffer.Read<UnityEngine.Vector3>();
            if (Flags.HasFlag(TransformFlags.Rotation))
                Transform.rotation = buffer.Read<UnityEngine.Quaternion>();
            if (Flags.HasFlag(TransformFlags.Scale))
                Transform.scale = buffer.Read<UnityEngine.Vector3>();
            if (Flags.HasFlag(TransformFlags.Velocity))
                Transform.velocity = buffer.Read<UnityEngine.Vector3>();
            if (Flags.HasFlag(TransformFlags.AngularVelocity))
                Transform.angularVelocity = buffer.Read<UnityEngine.Vector3>();

            return true;
        }
    }
}