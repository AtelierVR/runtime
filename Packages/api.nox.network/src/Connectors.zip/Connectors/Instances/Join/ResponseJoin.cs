
using System;
using api.nox.network.RelayInstances.Base;
using Buffer = api.nox.network.Utils.Buffer;
using Nox.CCK.Utils;

namespace api.nox.network.RelayInstances.Join
{
    public class ResponseJoin : InstanceResponse
    {
        public PlayerFlags Flags;
        public ushort PlayerId;
        public uint UserId;
        public string Display;
        public DateTimeOffset CreatedAt;
        public Engine Engine;
        public Platform Platform;

        public override bool FromBuffer(Buffer buffer)
        {
            PlayerId = buffer.Read<ushort>();
            Flags = buffer.Read<PlayerFlags>();
            PlayerId = buffer.Read<ushort>();
            UserId = buffer.Read<uint>();
            Display = buffer.Read<string>();
            CreatedAt = buffer.Read<DateTimeOffset>();
            Engine = buffer.Read<Engine>();
            Platform = buffer.Read<Platform>();
            return true;
        }
    }
}